var mongoose = require('mongoose');

var bookInfoSchema = mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    author: {
        type: String
    },
    publisher: {
        type: String
    },
    edition: {
        type: String
    },
    price: {
        type: Number,
        required: true
    },
    description: {
        type: String
    },
    uid: {
        type: String,
        required: true
    },
    status: {
        type: String
    },
    isAcademic: {
        type: String,
        required: true
    },
    bookType: {
        type: String,
        required: true
    },
    created_date: {
        type: Date,
        default: null
    },
    updated_date: {
        type: Date,
        default: null
    },
    bookAcademic: [{ type: mongoose.Schema.Types.ObjectId, ref: 'bookAcademicInfo' }],
    bookImages: [{ type: mongoose.Schema.Types.ObjectId, ref: 'bookimages' }],
    bookContact: [{ type: mongoose.Schema.Types.ObjectId, ref: 'bookcontact' }]
});


var BookInfo = module.exports = mongoose.model('bookinfo', bookInfoSchema);

// module.exports.getBooks = function (options, callback, limit) {
//     var offset = options.offset? options.offset : 0;
//     var limit = options.limit? options.limit : 10;
//     BookInfo.find({}).lean().sort({created_date:-1})
//     .populate('bookAcademic')
//     .populate('bookImages')
//     .populate('bookContact')
//     .skip(offset)
//     .limit(limit)
//     .exec(function(err, usersDocuments) {
//         callback(err,usersDocuments);
//     });
// }

// module.exports.getBooks = function (options, callback, limit) {
//     var offset = options.offset? options.offset : 0;
//     var limit = options.limit? options.limit : 10;
//     var query = {};
// for(var key in options.filters){ //could also be req.query and req.params
//   options.filters[key] !== "" ? query[key] = options.filters[key] : null;
// }
// query = {
//     college: "kmit"
// }
//     BookInfo.find(
//     ).lean().sort({created_date:-1})
//     .populate('bookAcademic')
//     .populate('bookContact')
//     .populate({path:'bookContact', match: {address:"safilguda"}})
//     .skip(offset)
//     .limit(limit)
//     .exec(function(err, usersDocuments) {
//         callback(err,usersDocuments);
//     });
// }

module.exports.getBooks = function (options, callback, limit) {
    var offset = options.offset? options.offset : 0;
    var limit = options.limit? options.limit : 10;
    var query = {};
for(var key in options.filters){ //could also be req.query and req.params
  options.filters[key] !== "" ? query[key] = options.filters[key] : null;
}

    BookInfo.aggregate([
        {
            $lookup: {
                from: "bookAcademicInfo",
                localField: "bookAcademic",
                foreignField: "_id",
                as:"book_Academic"
            }
         },
        {
            $lookup:{
                from:"bookimages",
                localField:"bookImages",
                foreignField:"_id",
                as:"bookImages"
            }
        },
        {
            $lookup:{
                from:"bookcontact",
                localField:"bookContact",
                foreignField:"_id",
                as:"bookContact"
            }
        },
        {
            $project:{
                _id:1,
                address:1,
                name:1
            }
        }
    ])
    
}

module.exports.getBookById = function (id,callback) {
    BookInfo.find({'uid': id}).lean().sort({created_date:-1})
    .populate('bookAcademic')
    .populate('bookImages')
    .populate('bookContact')
    .exec(function(err, usersDocuments) {
        callback(err,usersDocuments);
    });
}

module.exports.addBook = function (book,callback) {
    book.created_date = new Date();
    book.status = "NEW";
    // book.uid =  "5aa93239734d1d6b7120f9de";
    BookInfo.create(book,callback);
}

module.exports.updateBook = function (book, callback) {
    var query = {_id: book._id};
    var update = {
        name: book.name ? book.name :"No Name",
        author: book.author ? book.author :null,
        publisher:book.publisher ? book.publisher :null,
        edition:book.edition ? book.edition :null,
        price:book.price ? book.price :0,
        description:book.description ? book.description :null,
        uid:book.uid ? book.uid :"null",
        status:"NEW" ,
        isAcademic:book.isAcademic ? book.isAcademic :"N",
        bookType: book.bookType ? book.bookType : "OTHERS",
        bookAcademic : book.bookAcademic.length ? book.bookAcademic :[],
        bookImages : book.bookImages.length ? book.bookImages :[],
        bookContact : book.bookContact.length ? book.bookContact :[],
        updated_date: new Date()       
    }
    BookInfo.findOneAndUpdate(query, update, {new:true}, callback);
}

module.exports.deleteBook = function (id,callback) {
    var query = {_id: id};
    BookInfo.remove(query,callback);
}

module.exports.updateBookStatus = function (obj, callback) {
    var query = {_id: obj.bookId};
    var update = {
        status:obj.status,
        updated_date: new Date()
    }
    BookInfo.findOneAndUpdate(query, update, function (err, docs) {
        if(err){
            callback({erroMsg:err})
         }
         else {
            module.exports.getBookById(obj.userId,callback);
        }
    });
}