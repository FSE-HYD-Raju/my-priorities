var mongoose = require('mongoose');

var bookContactSchema = mongoose.Schema({
    phoneNo: {
        type: String
    },
    address: {
        type: String
    },
    landmark: {
        type: String
    },
    pincode: {
        type: Number,
        required: true
    },
    college: {
        type: String
    }
});

var BookContact = module.exports = mongoose.model('bookcontact', bookContactSchema);


module.exports.getBookContact = function (callback, limit) {
    BookContact.find(callback).limit(limit);
}

module.exports.getBookContactById = function (bookid, callback) {
    BookContact.findById(bookid, callback);
}

module.exports.addBookContact = function (bookContact, callback) {
    BookContact.create(bookContact, callback);
}

module.exports.updateBookContact = function (book, callback) {
    var update = {
        phoneNo: book.phoneNo ? book.phoneNo : null,
        address: book.address ? book.address : null,
        landmark: book.landmark ? book.landmark : null,
        pincode: book.pincode ? book.pincode : null,
        college: book.college ? book.college : null
    }
    if (book.bookContact[0] && book.bookContact[0]._id) {
        var query = { _id: book.bookContact[0]._id };
        BookContact.findOneAndUpdate(query, update, {new:true},  callback);
    } else {
        BookContact.create(update, callback);
    }
    
}

module.exports.deleteBookContact = function (id, callback) {
    var query = { _id: id };
    BookContact.remove(query, callback);
}
