var mongoose = require('mongoose');


var bookAcademicSchema = mongoose.Schema({
    course: {
        type: String
    },
    branch: {
        type: String
    },
    year: {
        type: Number
    },
    sem: {
        type: Number
    }
});

var BookAcademic = module.exports = mongoose.model('bookAcademicInfo', bookAcademicSchema);


module.exports.getBookAcademic = function (callback, limit) {
    BookAcademic.find(callback).limit(limit);
}

module.exports.getBookAcademicById = function (bookid,callback) {
    BookAcademic.find({'bookId':bookid},callback);
}

module.exports.addBookAcademic = function (bookAcademic,callback) {
    // if(bookAcademic.isAcademic == "Y"){
        BookAcademic.create(bookAcademic,callback);
    // } else {
    //     callback({_id: null});
    // }
    
}

module.exports.updateBookAcademic = function (book, callback) {
    var update = {
        course: book.course ? book.course : null,
        branch: book.branch ? book.branch : null,
        year:book.year ? book.year : null,
        sem:book.sem ? book.sem : null
    }
    if (book.bookAcademic[0] && book.bookAcademic[0]._id) {
        var query = { _id: book.bookAcademic[0]._id };
        BookAcademic.findOneAndUpdate(query, update, {new: true}, callback);
    } else {
        BookAcademic.create(update,callback);
    }
   
}

module.exports.deleteBookAcademic = function (id,callback) {
    var query = {_id: id};
    BookAcademic.remove(query,callback);
}
