var mongoose = require('mongoose');


var bookImageSchema = mongoose.Schema({
    image: {
        data: Buffer,
        contentType: String
    }
});

var BookImage = module.exports = mongoose.model('bookimages', bookImageSchema);

module.exports.getBookImage = function (callback, limit) {
    BookImage.find(callback).limit(limit);
}

module.exports.getBookImageById = function (bookid,callback) {
    BookImage.find({'bookId': bookid},callback);
}

module.exports.insertManyImages = function (arr,callback) {
    if(arr)
    BookImage.insertMany(arr,callback);
}

module.exports.updateImages = function (book, imgarr,callback) {
    if(book.bookImages.length){
        var bookImgIdArr = [];
        book.bookImages.forEach(function(element) {
            bookImgIdArr.push(element._id);
        }, this);
        BookImage.deleteMany({_id: { $in: bookImgIdArr}}, function(err,suc){})
    }
    if(imgarr){
       BookImage.insertMany(imgarr,callback);
    }
}